哈喽，亲爱的童鞋们，是不是觉得已经看完了？哈哈...告诉你，大错特错，笨猪写的才是一小部分。比如Redis，ElasticSearch这些数据库笨猪觉得已经有社区针对面试完善的非常好了，笨猪只是不想重复劳动(后面会给链接的哈)。还有常用的一些中间件，笨猪也没有写，是不是觉得笨猪很懒，其实并不是啦，理由同上，有人写了啊！笨猪又不傻，当然不会重复劳动。再说，要是写的不好，怕是要挨批了奥。最后，**算法！算法！算法！** 重要的事情说三遍，算法不能漏奥，每天一道leetcode，强化自己的算法能力奥！！！

👉 [【潜林】Java面试知识整理](https://www.cnblogs.com/fyql)


👉 [【Doocs社区】Java面试知识整理](https://doocs.gitee.io/advanced-java/#/)


👉 [bugstack虫洞栈](https://bugstack.cn/)


👉 [labuladong的算法小抄](https://labuladong.gitbook.io/algo/)


## 写到最后，恭祝童鞋们找到自己满意的工作！！！