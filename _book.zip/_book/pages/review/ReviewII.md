分布式的有状态和无状态

悲观锁和乐观锁

union和union all

Springboot连接池

跨域

b+树

可重入锁

Mysql默认的事物隔离级别

什么是分词器

Kafka如何保证顺序性

403是啥意思

1=1前面添加哪种符号实现sql注入

map的get()方法

Spring哪个注解实现动态添加配置信息的是否添加到Spring容器中

Spring哪种注解实现返回json格式的数据

Mybatis如何实现全局的limit offset，Mybaits拦截器

v-has

nginx实现图片的控制

explain

truncate和delete的区别

索引失效，联合索引

count(*)和count(某个字段)的区别

哨兵模式可以扩容吗

redis的数据结构

zset是如何排序的

mybatis接口为啥就能执行sql语句

查找所有数量大于1的结果

Arraylist是如何实现remove操作的

如何保证缓存与数据库一致性的

类加载机制

双亲委派机制

哪些对象可以作为gcroot

G1收集器何时回收垃圾

traceId是如何传递的

Apollo是如何实现监听变化的

Spring创建过程

Redis过期策略

LinkedHashMap TreeMap

coresize=0会出现什么情况

边车是如何保证交易发到后面的边车的

MVCC



















